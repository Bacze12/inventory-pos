import { describe, it } from "node:test";
import { expect } from '@jest/globals';

describe('App', () => {
    it('should work', () => {
      expect(true).toBe(true);
    });
  });
  