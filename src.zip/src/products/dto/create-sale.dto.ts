export class CreateSaleDto {
  customerId: string;
  items: any[];
}